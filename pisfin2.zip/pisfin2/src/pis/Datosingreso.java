package pis;


public class Datosingreso {
    String nombre;
    int edad;
    String sexo;
    String empleo;
   
   public Datosingreso ( String nombre,int edad,String sexo,String empleo){
        this.nombre=nombre;
        this.edad=edad;
        this.sexo=sexo;
        this.empleo=empleo;
}

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getSexo() {
        return sexo;
    }

    public String getEmpleo() {
        return empleo;
    }
   
}


