
package pis;

import javax.swing.JOptionPane;
  import java.awt.Image;

  import java.awt.Toolkit;

public class inicio extends javax.swing.JFrame {
    
    private todoslosdatos d = new todoslosdatos();
 calc1 inv;
    calc2 clc2;
    calc3 clc3;
    calc4 clc4;
    calc6 clc6 ;
    Somos qui;
    Login lgn;
    public static float totalmujeres;
    public static float totalhombres;
    public static float totalotros;
    public static float totalmenores;
    public static float totalmayores;
    public static float totaladultos;
     public static float totalindependientes;
    public static float totaldependientes;
    public static float totalsinempleo;
    

    public float getTotalMujeres() {
        return totalmujeres;
    }

    public float getTotalHombres() {
        return totalhombres;
    }

    public float getTotalOtros() {
        return totalotros;
    }

    public float getTotalMenores() {
        return totalmenores;
    }

    public float getTotalAdultos() {
        return totalhombres;
    }

    public float getTotalMayores() {
        return totalmayores;
    }

    public float getTotalDependientes() {
        return totaldependientes;
    }

    public float getTotalIndependientes() {
        return totalindependientes;
    }

    public float getTotalSinempleo() {
        return totalsinempleo;
    }

    public inicio() {
        initComponents();
            setResizable(false);
    }
     public Image getIconImage() {
    Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("IMG/inversion.png"));
    return retValue;
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuBar3 = new javax.swing.JMenuBar();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cmb1 = new javax.swing.JComboBox<>();
        txt_edad = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        Botoninformacion = new javax.swing.JButton();
        Botoniniciar = new javax.swing.JButton();
        cmb2 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        REGISTRO = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        jMenuItem3.setText("jMenuItem3");

        jMenu5.setText("File");
        jMenuBar3.add(jMenu5);

        jMenu6.setText("Edit");
        jMenuBar3.add(jMenu6);

        jMenuItem7.setText("jMenuItem7");

        jLabel5.setText("jLabel5");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jFormattedTextField1.setText("jFormattedTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("EDUFINANCIAME");
        setBackground(new java.awt.Color(129, 191, 255));
        setIconImage(getIconImage());

        jDesktopPane1.setPreferredSize(new java.awt.Dimension(820, 520));

        jPanel1.setBackground(new java.awt.Color(1, 152, 109));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 580));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel3.setText("NOMBRE:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, 84, 27));

        jLabel10.setFont(new java.awt.Font("Century Gothic", 3, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("EDUFINANCIAME");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, -1, -1));

        txt_nombre.setText("ingrese su nombre");
        txt_nombre.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_nombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txt_nombreMousePressed(evt);
            }
        });
        txt_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreActionPerformed(evt);
            }
        });
        jPanel1.add(txt_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, 197, -1));

        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel4.setText("EDAD:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, -1, -1));

        jLabel6.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel6.setText("SEXO:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 280, -1, -1));

        cmb1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        cmb1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Masculino", "Femenino", "Otro" }));
        cmb1.setBorder(null);
        jPanel1.add(cmb1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 280, 124, 30));

        txt_edad.setText("Ingrese su edad");
        txt_edad.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));
        txt_edad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txt_edadMousePressed(evt);
            }
        });
        jPanel1.add(txt_edad, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 220, 109, -1));

        jLabel7.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel7.setText("EMPLEO:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, -1, -1));

        Botoninformacion.setBackground(new java.awt.Color(255, 102, 102));
        Botoninformacion.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        Botoninformacion.setText("Finalizar");
        Botoninformacion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Botoninformacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotoninformacionActionPerformed(evt);
            }
        });
        jPanel1.add(Botoninformacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 420, 110, 30));

        Botoniniciar.setBackground(new java.awt.Color(153, 255, 153));
        Botoniniciar.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        Botoniniciar.setText("Registrarse");
        Botoniniciar.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Botoniniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotoniniciarActionPerformed(evt);
            }
        });
        jPanel1.add(Botoniniciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1713, 389, 137, 45));

        cmb2.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        cmb2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Dependiente", "Independiente", "Sin empleo" }));
        cmb2.setBorder(null);
        cmb2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb2ActionPerformed(evt);
            }
        });
        jPanel1.add(cmb2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 350, 124, -1));

        jLabel1.setFont(new java.awt.Font("Century Gothic", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BIENVENIDOS A LAS CALCULADORAS");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        REGISTRO.setBackground(new java.awt.Color(204, 255, 204));
        REGISTRO.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        REGISTRO.setText("Iniciar");
        REGISTRO.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        REGISTRO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                REGISTROActionPerformed(evt);
            }
        });
        jPanel1.add(REGISTRO, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 420, 110, 30));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/68247201-fondo-finanzas-dinero-economía-inconsútil-blanco-fondo-de-vector-transparente-sobre-el-tema-de.jpg"))); // NOI18N
        jLabel9.setText("jLabel9");
        jLabel9.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(153, 153, 153), new java.awt.Color(204, 204, 204)));
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 90, 860, 460));

        jDesktopPane1.setLayer(jPanel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 556, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/igeg25.png"))); // NOI18N
        jMenu4.setText(" Ingresos/Engresos");
        jMenu4.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N

        jMenuItem1.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/ingresos25.png"))); // NOI18N
        jMenuItem1.setText("Calculadora Ingresos");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem1);

        jMenuItem2.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/gastos25.png"))); // NOI18N
        jMenuItem2.setText("Calculadora Gastos");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem2);

        jMenuItem9.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jMenuItem9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/finanzas025.png"))); // NOI18N
        jMenuItem9.setText("Estado Financiero");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem9);

        jMenuBar2.add(jMenu4);

        jMenu7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/ahorro025.png"))); // NOI18N
        jMenu7.setText("Ahorro /Inversion");
        jMenu7.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N

        jMenuItem4.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jMenuItem4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/ahorro025.png"))); // NOI18N
        jMenuItem4.setText("Calculadora De ahorro");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem4);

        jMenuItem5.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jMenuItem5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/inversiones025.png"))); // NOI18N
        jMenuItem5.setText("Calculadora De inversiones");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem5);

        jMenuBar2.add(jMenu7);

        jMenu8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/datos025.png"))); // NOI18N
        jMenu8.setText("Datos Estadisticos");
        jMenu8.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N

        jMenuItem8.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jMenuItem8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/datos025.png"))); // NOI18N
        jMenuItem8.setText("Datos");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem8);

        jMenuBar2.add(jMenu8);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/info025.png"))); // NOI18N
        jMenu3.setText("Mas Información");
        jMenu3.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N

        jMenuItem6.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jMenuItem6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/info025.png"))); // NOI18N
        jMenuItem6.setText("Mas informacion");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem6);

        jMenuBar2.add(jMenu3);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 778, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
       
         inv = new calc1();
            jDesktopPane1.add(inv);
            inv.setVisible(true);
       
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:}
  

            clc2 = new calc2();
            jDesktopPane1.add(clc2);
            clc2.setVisible(true);
       
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
           

            clc3 = new calc3();
            jDesktopPane1.add(clc3);
            clc3.setVisible(true);
       
        
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        

            clc4 = new calc4();
            jDesktopPane1.add(clc4);
            clc4.setVisible(true);
       
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
         

        qui  = new Somos();
            jDesktopPane1.add(qui);
            qui.setVisible(true);
       
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        // TODO add your handling code here:
         if (lgn == null) {

            lgn = new Login();
            jDesktopPane1.add(lgn);
            lgn.setVisible(true);
        }
        else{
            lgn.setVisible(true);
        }
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void txt_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreActionPerformed

    private void BotoniniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotoniniciarActionPerformed
    JOptionPane.showMessageDialog(null, "Bienvenido te has registrado" );
      
  
    }//GEN-LAST:event_BotoniniciarActionPerformed
    
    private void cmb2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb2ActionPerformed

    private void BotoninformacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotoninformacionActionPerformed
        // TODO add your handling code here:
     
        for (int i = 0; i < d.cant; i++) {
            if (d.sexo[i].equals("Masculino")){
                d.hombres++;
            } else if (d.sexo[i].equals("Femenino")) {
                d.mujeres++;
            } else  if (d.sexo[i].equals("Otro")) {
     
                d.otros++;
            }
    }//GEN-LAST:event_BotoninformacionActionPerformed
       d.totalmuj = ((float)d.mujeres / d.cant) * 100;
        totalmujeres=d.totalmuj;
        d.totalhom = ((float)d.hombres / d.cant) * 100;
        totalhombres =d.totalhom;
        d.totalot = ((float)d.otros / d.cant) * 100;
        totalotros =d.totalot;
        
        for (int i = 0; i < d.cant; i++) {
            if (d.edad[i]<18){
                d.menor++;
            } else if (d.edad[i]>=18 && d.edad[i]<60) {
                d.adulto++;
            } else  if (d.edad[i]>60) {
     
                d.mayor++;
            }
            
        }
        d.totalmenor = ((float)d.menor / d.cant) * 100;
        totalmenores=d.totalmenor;
        d.totaladulto = ((float)d.adulto / d.cant) * 100;
        totaladultos =d.totaladulto;
        d.totalmayor = ((float)d.mayor / d.cant) * 100;
        
     
        for (int i = 0; i < d.cant; i++) {
            if (d.empleo[i].equals("Dependiente")){
                d.depe++;
            } else if (d.empleo[i].equals("Independiente")) {
                d.inde++;
            } else if (d.empleo[i].equals("Sin empleo")) {
                d.sinem++;
            }
       
    }
         d.totalinde = ((float)d.inde / d.cant) * 100;
        totalindependientes=d.totalinde;
        d.totaldepe = ((float)d.depe / d.cant) * 100;
        totaldependientes =d.totaldepe;
        d.totalsinem = ((float)d.sinem / d.cant) * 100;
        totalsinempleo =d.totalsinem;
    }
 
    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        // TODO add your handling code here:
         

            clc6 = new calc6();
            jDesktopPane1.add(clc6);
            clc6.setVisible(true);
        
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void REGISTROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_REGISTROActionPerformed
        // TODO add your handling code here:
            JOptionPane.showMessageDialog(null, "Bienvenido te has registrado" );

            if(d.cant<200){
            d.nombre[d.cant] = (txt_nombre.getText());

            d.empleo[d.cant] = (String) (cmb2.getSelectedItem());

            d.sexo[d.cant] = (String) (cmb1.getSelectedItem());

            d.edad[d.cant] = Integer.parseInt(txt_edad.getText());
             d.cant++;
            
       }
       else{
           
       }
        
    }//GEN-LAST:event_REGISTROActionPerformed

    private void txt_nombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_nombreMousePressed
        // TODO add your handling code here:
        txt_nombre.setText("");
    }//GEN-LAST:event_txt_nombreMousePressed

    private void txt_edadMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_edadMousePressed
        // TODO add your handling code here:
        txt_edad.setText("");
    }//GEN-LAST:event_txt_edadMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
          
                new inicio().setVisible(true);

            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Botoninformacion;
    private javax.swing.JButton Botoniniciar;
    private javax.swing.JButton REGISTRO;
    private javax.swing.JComboBox<String> cmb1;
    private javax.swing.JComboBox<String> cmb2;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuBar jMenuBar3;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField txt_edad;
    public static javax.swing.JTextField txt_nombre;
    // End of variables declaration//GEN-END:variables
}
