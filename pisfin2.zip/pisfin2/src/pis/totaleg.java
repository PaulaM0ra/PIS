package pis;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author elian
 */
public class totaleg {
    int alimentacion;
    int transporte;
    int arriendo;
    int servicios;
    int impuestos;
    int gastos;
    public totaleg (int alimentacion,int transporte,int arriendo,int servicios,int impuestos,int gastos){
    this.alimentacion=alimentacion;
    this.transporte=transporte;
    this.arriendo=arriendo;
    this.servicios=servicios;
    this.impuestos=impuestos;
    this.gastos=gastos;
    }
    public int totaleg(){
        return getAlimentacion()+getTransporte()+getArriendo()+getServicios()+getImpuestos()+getGastos();
    }
    public int getAlimentacion() {
        return alimentacion;
    }

    public int getTransporte() {
        return transporte;
    }

    public int getArriendo() {
        return arriendo;
    }

    public int getServicios() {
        return servicios;
    }

    public int getImpuestos() {
        return impuestos;
    }

    public int getGastos() {
        return gastos;
    }
    
}
