package pis;

/**
 *
 * @author Juan
 */
public class Calcular {
    public float dinero, porcentaje, años;

    public Calcular(float dinero, float porcentaje, float años) {
        this.dinero = dinero;
        this.porcentaje = porcentaje;
        this.años = años;
    }

    public float getDinero() {
        return dinero;
    }

    public void setDinero(float dinero) {
        this.dinero = dinero;
    }

    public float getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(float porcentaje) {
        this.porcentaje = porcentaje;
    }

    public float getAños() {
        return años;
    }

    public void setAños(float años) {
        this.años = años;
    }
    
    public float getMonto(){
        return  ((dinero*(porcentaje/100))*años)+dinero;
    }
}
