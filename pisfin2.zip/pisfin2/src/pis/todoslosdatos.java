/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pis;

/**
 *
 * @author crist_rwgcyl7
 */
public class todoslosdatos {
    public String[] nombre = new String[200];
    public String[] empleo = new String[200];
    public String[] sexo = new String[200];
    public int[] edad = new int[200];
    public int cant = 0;
    public int hombres = 0;
    public int mujeres = 0;
    public int otros = 0;
    public float totalmuj = 0;
    public float totalhom = 0;
    public float totalot = 0;
    public int menor = 0;
    public int mayor = 0;
    public int adulto = 0;
    public float totalmayor = 0;
    public float totalmenor = 0;
    public float totaladulto = 0;
    public int inde = 0;
    public int depe = 0;
    public int sinem = 0;
    public float totalinde = 0;
    public float totaldepe = 0;
    public float totalsinem = 0;


    
}
