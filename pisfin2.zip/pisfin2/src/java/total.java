/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java;

/**
 *
 * @author elian
 */
public class total {
 int salario;
    int prestacion;
    int negocio;
    int otros;
    public total ( int salario, int prestacion, int negocio, int otros){
        this.salario=salario;
        this.prestacion=prestacion;
        this.negocio=negocio;
        this.otros=otros;
    }

    total() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public int total(){
        return getSalario()+getPrestacion()+getNegocio()+getOtros();
    }
    public int getSalario() {
        return salario;
    }

    public int getPrestacion() {
        return prestacion;
    }

    public int getNegocio() {
        return negocio;
    }

    public int getOtros() {
        return otros;
    }
    
}    

